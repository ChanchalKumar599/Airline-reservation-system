Airline Reservation System - MySQL
=================================

Files included:
- airline_reservation_system.sql  : Full SQL script (create DB, tables, sample data, views, triggers, procedures)
- README.md                       : This file

How to use (MySQL Workbench / CLI):
1. Open MySQL Workbench and connect to your server.
2. Open the file `airline_reservation_system.sql`.
3. Run the script. It will create the database `AirlineDB` and populate sample data.
   - The script contains DELIMITER sections for triggers and stored procedures.
4. Example queries:
   - CALL sp_search_flights('Delhi','Mumbai','2025-11-05');
   - CALL sp_create_booking(2,1,5,3500.00,'PAY-0002');
   - SELECT * FROM v_available_seats WHERE flight_id = 1;
   - SELECT * FROM v_booking_summary;

Notes:
- Triggers use SIGNAL to raise errors when business rules are violated.
- The sample seats are intentionally minimal; expand Seats for full seat maps.
- Adjust schema (e.g., add airports, baggage, payments) as needed for production.
