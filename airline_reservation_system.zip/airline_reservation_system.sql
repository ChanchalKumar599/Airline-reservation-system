-- Airline Reservation System (MySQL)
-- Database: AirlineDB
-- This script creates schema, sample data, views, triggers, and example queries.

DROP DATABASE IF EXISTS AirlineDB;
CREATE DATABASE AirlineDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE AirlineDB;

-- 1. Flights table (normalized)
CREATE TABLE Flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(10) NOT NULL,
    origin VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    aircraft_model VARCHAR(100),
    total_seats INT NOT NULL DEFAULT 0,
    available_seats INT NOT NULL DEFAULT 0,
    UNIQUE KEY uk_flight_number_departure (flight_number, departure_time)
) ENGINE=InnoDB;

-- 2. Customers table
CREATE TABLE Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Seats table - each seat belongs to a flight
CREATE TABLE Seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    class ENUM('Economy','Premium Economy','Business','First') DEFAULT 'Economy',
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_window BOOLEAN DEFAULT FALSE,
    UNIQUE KEY uk_flight_seat (flight_id, seat_number),
    FOREIGN KEY (flight_id) REFERENCES Flights(flight_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Bookings table
CREATE TABLE Bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    flight_id INT NOT NULL,
    seat_id INT NOT NULL,
    booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Confirmed','Pending','Cancelled') DEFAULT 'Pending',
    price_paid DECIMAL(10,2) NOT NULL,
    payment_reference VARCHAR(100),
    CONSTRAINT fk_booking_customer FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_flight FOREIGN KEY (flight_id) REFERENCES Flights(flight_id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_seat FOREIGN KEY (seat_id) REFERENCES Seats(seat_id) ON DELETE CASCADE,
    UNIQUE KEY uk_seat_booking (flight_id, seat_id) -- prevents same seat double-booking for the same flight
) ENGINE=InnoDB;

-- Populate sample data
-- Sample flights
INSERT INTO Flights (flight_number, origin, destination, departure_time, arrival_time, aircraft_model, total_seats, available_seats)
VALUES
('AI101','Delhi','Mumbai','2025-11-05 08:00:00','2025-11-05 10:00:00','Boeing 737',150,150),
('AI202','Mumbai','Bengaluru','2025-11-06 13:30:00','2025-11-06 15:30:00','Airbus A320',180,180),
('AI303','Delhi','Kolkata','2025-11-07 06:00:00','2025-11-07 08:30:00','Boeing 737',160,160);

-- Sample customers
INSERT INTO Customers (first_name, last_name, email, phone)
VALUES
('Rahul','Sharma','rahul.sharma@example.com','+91-9876500001'),
('Anita','Verma','anita.verma@example.com','+91-9876500002'),
('Suresh','Kumar','suresh.kumar@example.com','+91-9876500003');

-- Generate seats for flights (simple example: create rows for a subset of seats)
-- Flight 1 seats
INSERT INTO Seats (flight_id, seat_number, class, price, is_window)
VALUES
(1,'1A','First',12000.00,TRUE),
(1,'1B','First',12000.00,FALSE),
(1,'5A','Business',7500.00,TRUE),
(1,'12A','Economy',3500.00,TRUE),
(1,'12B','Economy',3500.00,FALSE),
(1,'12C','Economy',3500.00,FALSE);

-- Flight 2 seats
INSERT INTO Seats (flight_id, seat_number, class, price, is_window)
VALUES
(2,'1A','Business',8000.00,TRUE),
(2,'15A','Economy',3000.00,TRUE),
(2,'15B','Economy',3000.00,FALSE);

-- Flight 3 seats
INSERT INTO Seats (flight_id, seat_number, class, price, is_window)
VALUES
(3,'2A','Business',7800.00,TRUE),
(3,'20A','Economy',3200.00,TRUE),
(3,'20B','Economy',3200.00,FALSE);

-- Sample confirmed booking
INSERT INTO Bookings (customer_id, flight_id, seat_id, status, price_paid, payment_reference)
VALUES
(1,1,4,'Confirmed',3500.00,'PAY-0001'); -- Rahul booked seat 12A on flight 1

-- Update available_seats to reflect sample bookings
UPDATE Flights f
LEFT JOIN (
    SELECT flight_id, COUNT(*) AS booked_count
    FROM Bookings
    WHERE status = 'Confirmed'
    GROUP BY flight_id
) b ON f.flight_id = b.flight_id
SET f.available_seats = GREATEST(f.total_seats - IFNULL(b.booked_count,0),0);

-- ------------------------------
-- Views and Queries
-- ------------------------------

-- View: Available seats per flight (detailed)
CREATE OR REPLACE VIEW v_available_seats AS
SELECT s.seat_id, s.flight_id, f.flight_number, s.seat_number, s.class, s.price
FROM Seats s
JOIN Flights f USING (flight_id)
LEFT JOIN Bookings b ON b.seat_id = s.seat_id AND b.flight_id = s.flight_id AND b.status = 'Confirmed'
WHERE b.booking_id IS NULL; -- seat is not confirmed booked

-- View: Flight availability summary
CREATE OR REPLACE VIEW v_flight_availability AS
SELECT f.flight_id, f.flight_number, f.origin, f.destination, f.departure_time, f.arrival_time,
       f.total_seats, f.available_seats
FROM Flights f;

-- Query examples (these can be run manually)
-- 1) Search flights between origin and destination on a date (use DATE(departure_time))
-- Example:
-- SELECT * FROM v_flight_availability WHERE origin='Delhi' AND destination='Mumbai' AND DATE(departure_time) = '2025-11-05';

-- 2) Find available seats for a flight_id = 1
-- SELECT * FROM v_available_seats WHERE flight_id = 1 ORDER BY class, seat_number;

-- 3) Booking summary per flight
CREATE OR REPLACE VIEW v_booking_summary AS
SELECT f.flight_id, f.flight_number, COUNT(b.booking_id) AS confirmed_bookings,
       SUM(b.price_paid) AS revenue
FROM Flights f
LEFT JOIN Bookings b ON b.flight_id = f.flight_id AND b.status = 'Confirmed'
GROUP BY f.flight_id, f.flight_number;

-- ------------------------------
-- Triggers
-- ------------------------------
DELIMITER $$

-- Before inserting a booking: ensure seat exists, is for same flight, and not already booked (confirmed)
CREATE TRIGGER trg_before_insert_booking
BEFORE INSERT ON Bookings
FOR EACH ROW
BEGIN
    DECLARE seat_flight_id INT;
    DECLARE already_booked INT;

    -- check seat exists and belongs to flight
    SELECT flight_id INTO seat_flight_id FROM Seats WHERE seat_id = NEW.seat_id;
    IF seat_flight_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Seat does not exist.';
    END IF;
    IF seat_flight_id <> NEW.flight_id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Seat does not belong to the specified flight.';
    END IF;

    -- check if seat already has a confirmed booking
    SELECT COUNT(*) INTO already_booked FROM Bookings
    WHERE flight_id = NEW.flight_id AND seat_id = NEW.seat_id AND status = 'Confirmed';
    IF already_booked > 0 AND NEW.status = 'Confirmed' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Seat already confirmed booked.';
    END IF;

    -- If booking is Confirmed, decrement Flights.available_seats
    IF NEW.status = 'Confirmed' THEN
        UPDATE Flights SET available_seats = available_seats - 1
        WHERE flight_id = NEW.flight_id AND available_seats > 0;
        -- Ensure available_seats wasn't negative
        IF ROW_COUNT() = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No available seats on this flight.';
        END IF;
    END IF;
END$$

-- After updating booking: if status changed to Cancelled from Confirmed, free the seat
CREATE TRIGGER trg_after_update_booking
AFTER UPDATE ON Bookings
FOR EACH ROW
BEGIN
    IF OLD.status = 'Confirmed' AND NEW.status = 'Cancelled' THEN
        UPDATE Flights SET available_seats = available_seats + 1 WHERE flight_id = NEW.flight_id;
    END IF;

    -- If previously cancelled and changed to confirmed, decrement available seats
    IF OLD.status = 'Cancelled' AND NEW.status = 'Confirmed' THEN
        UPDATE Flights SET available_seats = available_seats - 1 WHERE flight_id = NEW.flight_id AND available_seats > 0;
        IF ROW_COUNT() = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No available seats to confirm this booking.';
        END IF;
    END IF;
END$$

DELIMITER ;

-- ------------------------------
-- Stored procedures / utility queries
-- ------------------------------

-- Procedure: Search flights by origin/destination/date
DROP PROCEDURE IF EXISTS sp_search_flights;
DELIMITER $$
CREATE PROCEDURE sp_search_flights (
    IN p_origin VARCHAR(100),
    IN p_destination VARCHAR(100),
    IN p_departure_date DATE
)
BEGIN
    SELECT flight_id, flight_number, origin, destination, departure_time, arrival_time, total_seats, available_seats
    FROM Flights
    WHERE origin = p_origin
      AND destination = p_destination
      AND DATE(departure_time) = p_departure_date
    ORDER BY departure_time;
END$$
DELIMITER ;

-- Procedure: Create booking (transactional helper)
DROP PROCEDURE IF EXISTS sp_create_booking;
DELIMITER $$
CREATE PROCEDURE sp_create_booking (
    IN p_customer_id INT,
    IN p_flight_id INT,
    IN p_seat_id INT,
    IN p_price_paid DECIMAL(10,2),
    IN p_payment_ref VARCHAR(100)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Something went wrong; rollback
        ROLLBACK;
        SELECT 'ERROR: booking failed' AS message;
    END;

    START TRANSACTION;
    INSERT INTO Bookings (customer_id, flight_id, seat_id, status, price_paid, payment_reference)
    VALUES (p_customer_id, p_flight_id, p_seat_id, 'Confirmed', p_price_paid, p_payment_ref);
    COMMIT;
    SELECT LAST_INSERT_ID() AS booking_id;
END$$
DELIMITER ;

-- ------------------------------
-- Example reports
-- ------------------------------

-- 1) Booking counts and revenue per flight
-- SELECT * FROM v_booking_summary ORDER BY revenue DESC;

-- 2) Customer booking history
-- SELECT c.customer_id, CONCAT(c.first_name, ' ', c.last_name) AS customer_name, b.booking_id, b.flight_id, f.flight_number, s.seat_number, b.status, b.booking_time, b.price_paid
-- FROM Customers c
-- JOIN Bookings b ON b.customer_id = c.customer_id
-- JOIN Flights f ON f.flight_id = b.flight_id
-- JOIN Seats s ON s.seat_id = b.seat_id
-- ORDER BY b.booking_time DESC;

-- 3) Available seats per flight
-- SELECT flight_id, COUNT(*) AS available_seat_count FROM v_available_seats GROUP BY flight_id;

-- End of script
